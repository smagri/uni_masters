#include <cmath>

double squareroot (const double);
