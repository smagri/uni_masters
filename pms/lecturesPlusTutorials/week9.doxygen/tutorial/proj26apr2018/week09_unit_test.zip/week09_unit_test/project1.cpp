#include "project1.h"


double squareroot (const double num){

	return pow(num,0.5);
}
