//#include <string>

#include "RangerFusionInterface.h"


RangerFusionInterface::RangerFusionInterface(){

  // default fusion method is "min"
  //fusionMethod_ = "min";
  
};


// Virtual functions in RangerFusionInterface.h are pure virtual, that
// is the ones =0, thus need not be implemented here.
