^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package lama_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.3 (2015-02-11)
------------------
* Unchanged

0.1.1 (2015-01-08)
------------------
* all: move some messages from lama_interfaces to lama_msgs
  lama_interfaces: update install script
* Contributors: Gaël Ecorchard

0.1.0 (2015-01-07)
------------------
* First public release for Indigo
* Contributors: Gaël Ecorchard
