#include "laser.h"

laser::laser()
{
}
