#ifndef LASER_H
#define LASER_H

#include "sensor.h"

class laser : public Sensor
{
public:
    laser();
};

#endif // LASER_H
