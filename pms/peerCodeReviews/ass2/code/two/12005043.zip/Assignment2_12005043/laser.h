#ifndef LASER_H
#define LASER_H
#include "ranger.h"

class Laser: public Ranger  //Derived class Laser of base class Ranger
{
public:
    Laser();
};

#endif // LASER_H
