#ifndef SONAR_H
#define SONAR_H
#include "ranger.h"

class Sonar: public Ranger  //derived class sonar of base class ranger
{
public:
    Sonar();
};

#endif // SONAR_H
