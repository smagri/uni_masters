#include "RangerFusionInterface.h"

RangerFusionInterface::RangerFusionInterface()
{
}

void RangerFusionInterface::setRangers(vector<Ranger*> rangers){

}

vector<double> RangerFusionInterface::getFusedRangeData(){

}

vector<vector<double> > RangerFusionInterface::getRawRangeData(){

}
